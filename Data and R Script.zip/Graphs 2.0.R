getwd()
setwd("C:/Users/robin/Dropbox/Harvard SJD/NPL Paper")

require(dplyr)
require(zoo)
require(stringr)
require(ggplot2)
install.packages("matrixStats")
library(matrixStats)
## read EBA Report data (manually merged). pecking order:
# 1. IMF
# 2. Eurostat
# 3. Central Bank (Portugal)
# 4. EBA Report

EBA <- read.csv("EBA NPL Data.csv")
EBA <- EBA[-(1:3),]
EBA$PERIOD <- seq(as.Date("2015-07-01"), as.Date("2021-04-01"), by = "3 month")-1

### read IMF gross debt/GDP data

ndebt <- read.csv("IMF Debt Data mod.csv")
debt_c <- ndebt$Gross.debt.position....of.GDP.
ndebt <- t(ndebt[,c(-1,-34,-35)])
colnames(ndebt) <- debt_c
ndebt_mod <- ndebt[,EU_C]

debt_dates <- seq( as.Date("1990-12-31"), as.Date("2021-12-31"), by = "year")
ndebt_mod <- cbind(as.data.frame(debt_dates), as.data.frame(ndebt_mod))
ndebt_mod <- subset(ndebt_mod, ndebt_mod$debt_dates>(as.Date("2000-01-01")))
ndebt_mod[,-1] <- lapply(ndebt_mod[,-1], as.numeric)
ndebt_mod$mean <- rowMeans(ndebt_mod[,-1])

ndebt_mod$EU_mean_W <- rowMeans(ndebt_mod[,EU_C_W])
ndebt_mod$EU_mean_B <- rowMeans(ndebt_mod[,EU_C_B])
ndebt_mod$EU_mean_E <- rowMeans(ndebt_mod[,EU_C_E])
ndebt_mod$EU_mean_S <- rowMeans(ndebt_mod[,EU_C_S])

### read IMF data on household debt, corporate debt
hcdebt <- read.csv("IMF Household and Corp Debt mod.csv")
hcdebt$Indicator.Code <- as.factor(hcdebt$Indicator.Code)
hcdebt_mod <- hcdebt[1:42,]
hcdebt_mod <- hcdebt_mod[-11,]
hcdebt_mod <- as.data.frame(hcdebt_mod)

## house debt in Euros
house_debt_eur <- subset(hcdebt_mod, hcdebt_mod$Indicator.Code == "FSNHG_EUR")
colnam_hde <- house_debt_eur$Country.Name
house_debt_eur <- t(house_debt_eur[,c(-(1:5),-(52:53))])
colnames(house_debt_eur) <- colnam_hde
house_debt_eur <- as.data.frame(house_debt_eur)

house_debt_eur$Austria[1] <- house_debt_eur$Austria[2]
house_debt_eur$Austria[45] <- house_debt_eur$Austria[44]
house_debt_eur$Belgium[1] <- house_debt_eur$Belgium[5]
house_debt_eur$Germany[45] <- house_debt_eur$Germany[44]
house_debt_eur$Ireland[1] <- house_debt_eur$Ireland[2]

house_debt_eur <- house_debt_eur[1:45,]
house_debt_eur$Italy <- na.approx(house_debt_eur$Italy)

for(i in 1:ncol(house_debt_eur)){
  house_debt_eur[,i] <- (na.approx(house_debt_eur[,i]))
}

# calculate % change for data
per_hde_change <- 100*(house_debt_eur[45,]-house_debt_eur[41,])/house_debt_eur[41,]

##house debt % of GDP
house_debt_perc <- subset(hcdebt_mod, hcdebt_mod$Indicator.Code == "FSHG_PT")
colnam_hdp <- house_debt_perc$Country.Name
house_debt_perc <- t(house_debt_perc[,c(-(1:5),-(52:53))])
colnames(house_debt_perc) <- colnam_hdp

# fixing values
house_debt_perc <- house_debt_perc[1:45,]
house_debt_perc <- as.data.frame(house_debt_perc)
house_debt_perc$Lithuania[1] <- house_debt_perc$Lithuania[2]
house_debt_perc$Lithuania[c(44, 45)] <- house_debt_perc$Lithuania[43]
house_debt_perc$Germany[c(45)] <- house_debt_perc$Germany[44]
house_debt_perc$Belgium[1] <- house_debt_perc$Belgium[5]
house_debt_perc$Austria[c(45)] <- house_debt_perc$Austria[44]
house_debt_perc$Austria[1] <- house_debt_perc$Austria[2]
house_debt_perc$Sweden[1] <- house_debt_perc$Sweden[10]
house_debt_perc$Romania[1] <- house_debt_perc$Romania[2]
house_debt_perc$Ireland[1] <- house_debt_perc$Ireland[5]

for(i in 1:ncol(house_debt_perc)){
  house_debt_perc[,i] <- (na.approx(house_debt_perc[,i]))
}

house_debt_perc$rowmeans <- rowMeans(house_debt_perc)
house_debt_perc$rowvar <- rowVars(as.matrix(house_debt_perc))

#Corp debt %
corp_debt_perc <- subset(hcdebt_mod, hcdebt_mod$Indicator.Code == "FSTD_PT")
colnam_cdp <- corp_debt_perc$Country.Name
corp_debt_perc <- t(corp_debt_perc[,c(-(1:5),-(51:53))])
colnames(corp_debt_perc) <- colnam_cdp
corp_debt_perc <- as.data.frame(corp_debt_perc)
corp_debt_perc$Italy <- na.approx(corp_debt_perc$Italy)

# add dates to everything
hcdebt_PERIOD <- seq(as.Date("2010-01-01"), as.Date("2021-01-01"), by = "3 month")-1
house_debt_perc$dates <- hcdebt_PERIOD
corp_debt_perc$dates <- hcdebt_PERIOD

### read IMF NPL data

IMF_EU_NPL <- read.csv("IMF NPL data, Europe mod.csv")
IMF_EU_NPL <- as.data.frame(IMF_EU_NPL)

IMF_EU_NPL <- IMF_EU_NPL[1:47,-c(2,3,5)]
colnames(IMF_EU_NPL)[1] <- "Country"

EU_C <- c("Austria","Belgium","Croatia","Cyprus","Czech Republic","Denmark",
          "Estonia","Finland","France","Germany","Greece","Hungary","Ireland",
          "Italy","Latvia","Lithuania","Luxembourg","Malta","Netherlands",
          "Poland","Portugal","Romania","Slovakia","Slovenia","Spain","Sweden")
EU_C_W <- c("Austria","France","Belgium","Germany","Netherlands","Luxembourg","Ireland")
EU_C_S <- c("Italy","Greece","Portugal","Spain","Cyprus", "Malta")
EU_C_N <- c("Denmark","Finland","Sweden", "Estonia","Lithuania","Latvia")
EU_C_E <- c("Croatia", "Hungary","Poland","Romania","Slovakia",
            "Slovenia")
EU_C_B <- c("Lithuania","Latvia","Estonia","Finland")
EU_C_DAT <- c(EU_C_W, EU_C_S, EU_C_B, EU_C_E)

IMF_NPL <- aggregate(x=IMF_EU_NPL[3:67], by = list(name=IMF_EU_NPL$Country), FUN=max, na.rm=TRUE)

IMF_NPL[IMF_NPL == "-Inf"] <- NA

Date <- seq(as.Date("2005-04-01"), as.Date("2021-04-01"), by = "3 month")-1
country_names <- IMF_NPL[,1]
country_names <- gsub("^(.*?),.*","\\1", country_names)
country_names <- gsub("^Slovak.*","Slovakia", country_names)

IMF_NPL <- IMF_NPL[,-1]

IMF_NPL_mod <- cbind(as.data.frame(Date),t(IMF_NPL))
colnames(IMF_NPL_mod) <- c("Date", country_names)
colnames(IMF_NPL_mod)
IMF_NPL_mod[,c("Austria", "Belgium")]
IMF_NPL_mod$EU_mean <- rowMeans(IMF_NPL_mod[,-1], na.rm=TRUE)

### read Eurostat data

Estat_NPL <- read.csv("Eurostat 2015-2021.csv")
country_names_Estat <- Estat_NPL$Series.key
Date_Estat <- seq(as.Date("2021-04-01"), as.Date("2015-07-01"), by = "-3 month")-1

Estat_NPL_mod <- cbind(as.data.frame(Date_Estat), t(Estat_NPL[,-1]))
colnames(Estat_NPL_mod) <- c("Date", country_names_Estat)

## merge data. Replace NA in IMF data with Eurostat data

IMF_NPL_mod[,country_names[1]]

npl_eu_mer <- IMF_NPL_mod[IMF_NPL_mod$Date>=as.Date("2015-06-30"),-26]

for(j in 2:ncol(npl_eu_mer)){                 ## j is the col number
  for(i in 1:nrow(npl_eu_mer)){               ## i is the row number
    if(is.na(npl_eu_mer[i,j])==TRUE){
    row_dat <- npl_eu_mer$Date[i]
    col_country <- colnames(npl_eu_mer[j])
    npl_eu_mer[i,j] <- Estat_NPL_mod[Estat_NPL_mod$Date==row_dat, col_country]
    }
  }  
}

## adding leftover amounts
npl_eu_mer["X2021Q1","Portugal"] <- 4.6 ## source Bank of Portugal
npl_eu_mer["X2021Q1","Poland"] <- 4.0 ## source EBA

npl_eu_mer[c("X2015Q2","X2015Q3"),c("Bulgaria","Luxembourg")] <- c(13.14128,12.67603,2.09367,1.96774) ## EBA


npl_eu_mer$means <- rowMeans(npl_eu_mer[,-1], na.rm=TRUE)

ggplot(data = npl_eu_mer, aes(Date)) + 
  geom_line(aes(y=means)) +
  theme(axis.text.x = element_text(angle = 90, vjust=0.5),  # rotate x axis text
      panel.grid.minor = element_blank())

plot(x=npl_eu_mer$Date, y = npl_eu_mer$means, type = "o", xaxt = "n", yaxt="n", ylim=c(3, 12),
ylab= "NPL Ratio", xlab="Date", lwd=2)
axis(side=2, seq(3,12,1), las=2)
axis(side=1, npl_eu_mer$Date, paste(format(npl_eu_mer$Date, "%Y"), "Q2", sep="/"))


date_vec <- npl_eu_mer$Date[c(1, 5, 9, 13, 17, 21, 24)]

### Debt calcs

ndebt_mod <- ndebt[,EU_C]

debt_dates <- seq( as.Date("1990-12-31"), as.Date("2021-12-31"), by = "year")
ndebt_mod <- cbind(as.data.frame(debt_dates), as.data.frame(ndebt_mod))
ndebt_mod <- subset(ndebt_mod, ndebt_mod$debt_dates>(as.Date("2000-01-01")))
ndebt_mod[,-1] <- lapply(ndebt_mod[,-1], as.numeric)
ndebt_mod$mean <- rowMeans(ndebt_mod[,-1])

ndebt_mod$EU_mean_W <- rowMeans(ndebt_mod[,EU_C_W])
ndebt_mod$EU_mean_B <- rowMeans(ndebt_mod[,EU_C_B])
ndebt_mod$EU_mean_E <- rowMeans(ndebt_mod[,EU_C_E])
ndebt_mod$EU_mean_S <- rowMeans(ndebt_mod[,EU_C_S])


### Figure 1 Mean NPL Ratio across all EU Countries 
xlab <- c("2015-Q2", "2016-Q2", "2017-Q2", "2018-Q2", "2019-Q2", "2020-Q2", "2021-Q1")
  
jpeg(file = "./Graphs//Mean NPL Ratio (EU).jpeg")

plot(x=npl_eu_mer$Date, y = npl_eu_mer$means, type = "o", xaxt = "n", yaxt="n", ylim=c(3, 11), yaxs="i",
     ylab= "NPL Ratio (%)", xlab="", lwd=2)
axis(side=2, seq(3,12,1), las=2)
axis(side=1, date_vec, labels= FALSE)
text(x = date_vec, y = 2.5, labels = xlab, xpd= NA, srt = 15)
abline(v=npl_eu_mer$Date, col=alpha(rgb(0,0,0), 0.2))
abline(v=date_vec[1:7], col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(3,12,1), col=alpha(rgb(0,0,0), 0.2))
title(main = "Figure 1: Mean NPL Ratio across Member States")
title(sub = "Source: IMF Financial Soundness Indicators, Central Banks, EBA Reports.", line = 3)



### OPTIONAL figure: mean NPL Ratio across all EU Countries (EBA Report data)
jpeg(file = "./Graphs//Mean NPL Ratio (EU) EBA Data.jpeg")

plot(x=EBA$PERIOD, y = EBA$Average*100, type = "o", xaxt = "n", yaxt="n", ylim=c(3, 11), yaxs="i",
     ylab= "NPL Ratio (%)", xlab="", lwd=2)
axis(side=2, seq(3,12,1), las=2)
axis(side=1, date_vec, labels= FALSE)
text(x = date_vec, y = 2.5, labels = xlab, xpd= NA, srt = 15)
abline(v=npl_eu_mer$Date, col=alpha(rgb(0,0,0), 0.2))
abline(v=date_vec[1:7], col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(3,12,1), col=alpha(rgb(0,0,0), 0.2))
title(main = "Figure 6: Mean NPL Ratio across Member States")
title(sub = "Source: EBA Reports.", line = 3)

### Figure 2: Sum of NPLs for all Member States (Euros), EBA Report data

jpeg(file = "./Graphs//Aggregate NPLs (EU).jpeg")

plot(x=EBA$PERIOD, y = EBA$num/1000000000, type = "o", xaxt = "n", yaxt="n", ylim = c(400, 1000), yaxs="i",
     ylab= "Aggregate Amount (Billions)", xlab="", lwd=2)
axis(side=2, seq(400,1000,100), las=2)
axis(side=1, date_vec, labels= FALSE)
text(x = date_vec, y = 362, labels = xlab, xpd= NA, srt = 15)
abline(v=npl_eu_mer$Date, col=alpha(rgb(0,0,0), 0.2))
abline(v=date_vec[1:7], col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(400,1000,100), col=alpha(rgb(0,0,0), 0.2))
title(main = "Figure 3: Aggregate Amount of NPLs Across the EU (Euros)")
title(sub = "Source: EBA Reports.", line = 3)

## Figure 3: Mean NPL Ratio Breakdown by Region
npl_eu_mer$EU_mean_W <- rowMeans(npl_eu_mer[,EU_C_W])
npl_eu_mer$EU_mean_B <- rowMeans(npl_eu_mer[,EU_C_B])
npl_eu_mer$EU_mean_E <- rowMeans(npl_eu_mer[,EU_C_E])
npl_eu_mer$EU_mean_S <- rowMeans(npl_eu_mer[,EU_C_S])

jpeg(file = "./Graphs//Mean NPLs by Region.jpeg")

plot(x=npl_eu_mer$Date, y = npl_eu_mer$EU_mean_W, type = "o", xaxt = "n", yaxt="n", yaxs="i", ylim=c(0, 25),
     ylab= "NPL Ratio (%)", xlab="", lwd=2, pch=16)
axis(side=2, seq(0,25,2), las=2)
axis(side=1, date_vec, labels= FALSE)
text(x = date_vec, y = -1.55, labels = xlab, xpd= NA, srt = 15)
abline(v=npl_eu_mer$Date, col=alpha(rgb(0,0,0), 0.2))
abline(v=date_vec[1:7], col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(0,25,2), col=alpha(rgb(0,0,0), 0.2))
lines(x=npl_eu_mer$Date, y = npl_eu_mer$EU_mean_B, type = "o", xaxt = "n", yaxt="n", col="red", lwd=2, pch=16)
lines(x=npl_eu_mer$Date, y = npl_eu_mer$EU_mean_E, type = "o", xaxt = "n", yaxt="n", col="blue", lwd=2, pch=16)
lines(x=npl_eu_mer$Date, y = npl_eu_mer$EU_mean_S, type = "o", xaxt = "n", yaxt="n", col="green", lwd=2, pch=16)
title(main = "Figure 7: Mean NPL Ratio by EU Region")
legend("topright", legend=c("Western","North-Eastern","Eastern","Southern"), col = c("black","red","blue","green"), lty=1, lwd=2,
       pch=c(16,16,16,16))
title(sub = "Source: IMF Financial Soundness Indicators, Central Banks, EBA Reports. \"North-Eastern\"
includes Lithuania, Latvia, Estonia, and Finland.", line = 3.8)

## Figure 4: Italy, Portugal, Greece, Cyprus

jpeg(file = "./Graphs//Mean NPLs for IPGC.jpeg")

plot(x=npl_eu_mer$Date, y = npl_eu_mer$Italy, type = "o", xaxt = "n", yaxt="n", yaxs="i", ylim=c(0, 50),
     ylab= "NPL Ratio (%)", xlab="", lwd=2, pch=16)
axis(side=2, seq(0,50,4), las=2)
axis(side=1, date_vec, labels= FALSE)
text(x = date_vec, y = -3.2, labels = xlab, xpd= NA, srt = 15)
abline(v=npl_eu_mer$Date, col=alpha(rgb(0,0,0), 0.2))
abline(v=date_vec[1:7], col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(0,60,4), col=alpha(rgb(0,0,0), 0.2))
lines(x=npl_eu_mer$Date, y = npl_eu_mer$Greece, type = "o", xaxt = "n", yaxt="n", col="red", lwd=2, pch=16)
lines(x=npl_eu_mer$Date, y = npl_eu_mer$Cyprus, type = "o", xaxt = "n", yaxt="n", col="blue", lwd=2, pch=16)
lines(x=npl_eu_mer$Date, y = npl_eu_mer$Portugal, type = "o", xaxt = "n", yaxt="n", col="green", lwd=2, pch=16)
title(main = "Figure 2: Italy, Greece, Cyprus, and Portugal Mean NPL Ratio")
legend("topright", legend=c("Italy","Greece","Cyprus","Portugal"), col = c("black","red","blue","green"), lty=1, lwd=2,
       pch=c(16,16,16,16))
title(sub = "Source: IMF Financial Soundness Indicators, Central Banks, EBA Reports.", line = 3)

## Figure 5: average debt across EU Countries (% of GDP)

dates.as.years.debt <- c(seq(2000,2021,2))
debt_dates_axis <- c(seq( as.Date("2000-12-31"), as.Date("2021-12-31"), by = "2 year"))
xlabdebt <- (seq(2000, 2021, 2))

jpeg(file = "./Graphs//Average Debt to GDP (EU).jpeg")

plot(x=ndebt_mod$debt_dates, y = ndebt_mod$mean, type = "o", xaxt = "n", yaxt="n", ylim=c(0, 100), yaxs="i",
     ylab= "Debt/GDP Ratio (%)", xlab="", lwd=2)
axis(side=2, seq(0,100,10), las=2)
axis(side=1, ndebt_mod$debt_dates, labels= FALSE)
text(x = debt_dates_axis, y = -5, labels = xlabdebt, xpd= NA)
abline(v=ndebt_mod$debt_dates, col=alpha(rgb(0,0,0), 0.2))
abline(v=debt_dates_axis, col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(0,100,10), col=alpha(rgb(0,0,0), 0.2))
title(main = "Figure 4: Mean Debt-to-GDP Ratio across Member States")
title(sub = "Source: IMF World Economic Outlook. 2021 datapoint based on IMF estimates.", line = 3)

## Figure 6: Average debt across EU Regions

jpeg(file = "./Graphs//Average Debt to GDP (EU, by region).jpeg")

plot(x=ndebt_mod$debt_dates, y = ndebt_mod$EU_mean_W, type = "o", xaxt = "n", yaxt="n", yaxs="i", ylim=c(0, 150),
     ylab= "Debt/GDP Ratio (%)", xlab="", lwd=2, pch=16)
axis(side=2, seq(0,150,15), las=2)
axis(side=1, ndebt_mod$debt_dates, labels= FALSE)
text(x = debt_dates_axis, y = -7.5, labels = xlabdebt, xpd= NA)
abline(v=ndebt_mod$debt_dates, col=alpha(rgb(0,0,0), 0.2))
abline(v=debt_dates_axis, col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(0,150,15), col=alpha(rgb(0,0,0), 0.2))
lines(x=ndebt_mod$debt_dates, y = ndebt_mod$EU_mean_B, type = "o", xaxt = "n", yaxt="n", col="red", lwd=2, pch=16)
lines(x=ndebt_mod$debt_dates, y = ndebt_mod$EU_mean_E, type = "o", xaxt = "n", yaxt="n", col="blue", lwd=2, pch=16)
lines(x=ndebt_mod$debt_dates, y = ndebt_mod$EU_mean_S, type = "o", xaxt = "n", yaxt="n", col="green", lwd=2, pch=16)
title(main = "Figure 5: Mean Debt-to-GDP Ratio by EU Region")
legend("topleft", legend=c("Western","North-Eastern","Eastern","Southern"), col = c("black","red","blue","green"), lty=1, lwd=2,
       pch=c(16,16,16,16))
title(sub = "Source: IMF World Economic Outlook. \"North-Eastern\" includes Lithuania, 
      Latvia, Estonia, and Finland. 2021 datapoint based on IMF estimates.", line = 3.8)

## Figure 7: debt/GDP in Italy, Portugal, Greece, Cyprus

jpeg(file = "./Graphs//Average Debt to GDP IPGC.jpeg")

plot(x=ndebt_mod$debt_dates, y = ndebt_mod$Italy, type = "o", xaxt = "n", yaxt="n", yaxs="i", ylim=c(30, 230),
     ylab= "Dept/GDP Ratio (%)", xlab="", lwd=2, pch=16)
axis(side=2, seq(30,230,20), las=2)
axis(side=1, ndebt_mod$debt_dates, labels= FALSE)
text(x = debt_dates_axis, y = 20, labels = xlabdebt, xpd= NA)
abline(v=ndebt_mod$debt_dates, col=alpha(rgb(0,0,0), 0.2))
abline(v=debt_dates_axis, col=alpha(rgb(0,0,0), 0.7))
abline(h=seq(50,250,20), col=alpha(rgb(0,0,0), 0.2))
lines(x=ndebt_mod$debt_dates, y = ndebt_mod$Greece, type = "o", xaxt = "n", yaxt="n", col="red", lwd=2, pch=16)
lines(x=ndebt_mod$debt_dates, y = ndebt_mod$Cyprus, type = "o", xaxt = "n", yaxt="n", col="blue", lwd=2, pch=16)
lines(x=ndebt_mod$debt_dates, y = ndebt_mod$Portugal, type = "o", xaxt = "n", yaxt="n", col="green", lwd=2, pch=16)
title(main = "Figure 8: Italy, Greece, Cyprus, and Portugal Debt to GDP Ratio")
legend("topleft", legend=c("Italy","Greece","Cyprus","Portugal"), col = c("black","red","blue","green"), lty=1, lwd=2,
       pch=c(16,16,16,16))
title(sub = "Source: IMF World Economic Outlook. 2021 datapoint based on IMF estimates.", line = 3)

## Figure 8: househeld debt percent of GDP by country
hs_debt_dates <- c(seq( as.Date("2010-01-01"), as.Date("2021-01-01"), by = "1 year"))
hs_debt_lab <- seq(2010, 2021, 1)

jpeg(file = "./Graphs//Household debt to GDP.jpeg")

plot(x=house_debt_perc$dates, y = house_debt_perc$rowmeans, type = "l", lty = 2, xaxt = "n", yaxt="n", yaxs="i", ylim=c(30, 230),
     ylab= "Dept/GDP Ratio (%)", xlab="", lwd=2, pch=16)
axis(side=2, seq(30,230,20), las=2)
axis(side=1, ndebt_mod$debt_dates, labels= FALSE)
text(x = hs_debt_dates, y = 20, labels = hs_debt_lab, xpd= NA)
abline(v=hs_debt_dates, col=alpha(rgb(0,0,0), 0.2))
abline(h=seq(30,230,20), col=alpha(rgb(0,0,0), 0.2))
lines(x=house_debt_perc$dates, y = house_debt_perc$Italy, type = "l", xaxt = "n", yaxt = "n", lwd = 2, pch = 16)
lines(x=house_debt_perc$dates, y = house_debt_perc$Greece, type = "l", xaxt = "n", yaxt="n", col="red", lwd=2, pch=16)
lines(x=house_debt_perc$dates, y = house_debt_perc$Ireland, type = "l", xaxt = "n", yaxt="n", col="blue", lwd=2, pch=16)
lines(x=house_debt_perc$dates, y = house_debt_perc$Portugal, type = "l", xaxt = "n", yaxt="n", col="green", lwd=2, pch=16)
title(main = "Figure 9: EU Country Sample, Italy, Greece, Ireland,
      and Portugal Household Debt to GDP Ratio")
legend("topleft", legend=c("Sample Mean","Italy","Greece","Ireland","Portugal"), col = c("black","black","red","blue","green"), 
       lty=c(2,1,1,1,1), lwd=2)
title(sub = "Source: IMF Financial Soundness Indicators.", line = 3)

## Figure 9: corp debt percent of GDP by country
jpeg(file = "./Graphs//Corporate debt to GDP.jpeg")

plot(x=corp_debt_perc$dates, y = corp_debt_perc$Italy, type = "l", lty = 1, xaxt = "n", yaxt="n", yaxs="i", ylim=c(30, 290),
     ylab= "Dept/GDP Ratio (%)", xlab="", lwd=2, pch=16)
axis(side=2, seq(30,290,26), las=2)
axis(side=1, ndebt_mod$debt_dates, labels= FALSE)
text(x = hs_debt_dates, y = 15, labels = hs_debt_lab, xpd= NA)
abline(v=hs_debt_dates, col=alpha(rgb(0,0,0), 0.2))
abline(h=seq(30,290,26), col=alpha(rgb(0,0,0), 0.2))
lines(x=corp_debt_perc$dates, y = corp_debt_perc$Greece, type = "l", xaxt = "n", yaxt = "n", col="red",lwd = 2, pch = 16)
lines(x=corp_debt_perc$dates, y = corp_debt_perc$France, type = "l", xaxt = "n", yaxt="n", col="blue", lwd=2, pch=16)
lines(x=corp_debt_perc$dates, y = corp_debt_perc$Portugal, type = "l", xaxt = "n", yaxt="n", col="green", lwd=2, pch=16)
title(main = "Figure 10: Italy, Greece, France,
      and Portugal Corporate (Nonfinance) Debt to GDP Ratio")
legend("topright", legend=c("Italy","Greece","France","Portugal"), col = c("black","red","blue","green"), 
       lwd=2)
title(sub = "Source: IMF Financial Soundness Indicators.", line = 3)

